# Speech to text Converter 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nishith/pen/ZxGBew](https://codepen.io/Nishith/pen/ZxGBew).

